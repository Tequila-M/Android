package com.wfuhui.modules.project.dao;

import com.wfuhui.modules.project.entity.TeacherEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

import org.apache.ibatis.annotations.Mapper;

/**
 * 技师
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface TeacherDao extends BaseDao<TeacherEntity> {
	
}
