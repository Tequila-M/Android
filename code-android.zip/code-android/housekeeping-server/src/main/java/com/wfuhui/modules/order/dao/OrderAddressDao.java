package com.wfuhui.modules.order.dao;

import org.apache.ibatis.annotations.Mapper;

import com.wfuhui.modules.order.entity.OrderAddressEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

/**
 * 订单配送表
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 */
@Mapper
public interface OrderAddressDao extends BaseDao<OrderAddressEntity> {

	OrderAddressEntity queryByOrderId(Integer orderId);
	
}
