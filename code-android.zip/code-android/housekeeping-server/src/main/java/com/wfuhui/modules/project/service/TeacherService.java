package com.wfuhui.modules.project.service;

import com.wfuhui.modules.project.entity.TeacherEntity;

import java.util.List;
import java.util.Map;

/**
 * 技师
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 * @date 2021-01-11 21:15:29
 */
public interface TeacherService {
	
	TeacherEntity queryObject(Integer id);
	
	List<TeacherEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(TeacherEntity teacher);
	
	void update(TeacherEntity teacher);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
