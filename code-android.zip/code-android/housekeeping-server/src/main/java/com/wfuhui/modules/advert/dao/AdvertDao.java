package com.wfuhui.modules.advert.dao;

import org.apache.ibatis.annotations.Mapper;

import com.wfuhui.modules.advert.entity.AdvertEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

/**
 * @author lzl
 * @email 2803180149@qq.com
 */
@Mapper
public interface AdvertDao extends BaseDao<AdvertEntity> {
	
}
