package com.wfuhui.modules.project.dao;

import com.wfuhui.modules.project.entity.ProjectEntity;
import com.wfuhui.modules.sys.dao.BaseDao;

import org.apache.ibatis.annotations.Mapper;

/**
 * 项目
 * 
 * @author lizhengle
 * @email 2803180149@qq.com
 * @date 2020-12-01 11:32:48
 */
@Mapper
public interface ProjectDao extends BaseDao<ProjectEntity> {
	
}
