package com.wfuhui.housekeeping.util;

/**
 * Created by taobishe.cn
 */

public class Constant {
    public static final String BASE_URL = "http://localhost:8080";

    public static final String TOKEN = "token";

    public static final String RESP_CODE = "code";

    public static final String RESP_MSG = "msg";
}
